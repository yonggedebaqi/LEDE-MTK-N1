# DVB-For-Openwrt
openwrt 下的一些DVB应用软件，比如tvheadend,oscam等。
